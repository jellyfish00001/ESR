namespace ERS.DomainServices
{
    public class BDDataDictionaryDomainService
    {
        
    }
}