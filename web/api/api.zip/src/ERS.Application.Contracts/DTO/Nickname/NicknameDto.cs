namespace ERS.Application.Contracts.DTO.Nickname
{
    public class NicknameDto
    {
        public string nickname { get; set; }
        public string name { get; set; }
    }
}