namespace ERS.Application.Contracts.DTO.Invoice
{
    public class InvoiceStat
    {
        public string expcode { get; set; }
        public bool status { get; set; }
    }
}