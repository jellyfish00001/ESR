namespace ERS.DTO.Invoice
{
    public class ERSInvDto
    {
        public string Invcode { get; set; }
        public string Invno { get; set; }
    }
}