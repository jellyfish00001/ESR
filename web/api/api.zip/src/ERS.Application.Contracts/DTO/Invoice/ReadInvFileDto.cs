namespace ERS.DTO.Invoice
{
    public class ReadInvFileDto
    {
        public string url { get; set; }
    }
}