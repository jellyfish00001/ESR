using System;
namespace ERS.DTO.Invoice
{
    public class ShareInvoiceDto
    {
        public Guid Id { get; set; }
        public string emplid { get; set; }
    }
}