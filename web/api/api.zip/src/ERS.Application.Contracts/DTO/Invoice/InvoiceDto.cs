namespace ERS.Application.Contracts.DTO.Invoice
{
    // public class InvoiceDto
    // {
    //     public string rno { get; set; }
    //     public int seq { get; set; }
    //     public int item { get; set; }
    //     //发票代码
    //     public string invcode { get; set; }
    //     //发票号码
    //     public string invno { get; set; }
    //     //开票金额
    //     public decimal amount { get; set; }
    //     //开票日期
    //     public DateTime? invdate { get; set; }
    //     //税额
    //     public decimal taxamount { get; set; }
    //     //价税合计金额
    //     public decimal oamount { get; set; }
    //     //发票状态
    //     public string invstat { get; set; }
    //     //异常报销金额
    //     public decimal abnormalamount { get; set; }
    //     //税金损失
    //     public decimal taxloss { get; set; }
    //     //币别
    //     public string curr { get; set; }
    //     //承担方
    //     public string undertaker { get; set; }
    //     //付款方名称
    //     public string paymentName { get; set; }
    //     //付款方证件号
    //     public string paymentNo { get; set; }
    //     //收款方名称
    //     public string collectionName { get; set; }
    //     //收款方证件号
    //     public string collectionNo { get; set; }
    //     //异常信息
    //     public string expdesc{get;set;}
    //     //发票异常原因
    //    public string  expcode{get;set;}
    //     //发票名称显示
    //     public string invdesc{get;set;}
    //     public string reason { get; set; }
    //     public string abnormal { get; set; }
    // }
}