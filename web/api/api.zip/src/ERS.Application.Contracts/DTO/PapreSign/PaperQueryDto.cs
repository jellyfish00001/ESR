namespace ERS.DTO.PapreSign
{
    public class PaperQueryDto
    {
        public string emplid { get; set; }// 签核人
    }
}