namespace ERS.Application.Contracts.DTO.CashFile
{
    public class CreateUpdateCashFileDto
    {
    }
}