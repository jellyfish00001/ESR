namespace ERS.Application.Contracts.DTO.CashFile
{
    public class CashFileDto
    {
        public string rno { get; set; }
        public int seq { get; set; }
        public int item { get; set; }
        public string formcode { get; set; }
        public string company { get; set; }
    }
}