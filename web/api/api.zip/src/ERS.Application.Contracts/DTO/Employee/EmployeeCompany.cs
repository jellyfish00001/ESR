namespace ERS.Application.Contracts.DTO.Employee
{
    public class EmployeeCompany
    {
        public string emplid { get; set; }
        public string name { get; set; }
        public string ename { get; set; }
    }
}