﻿namespace ERS.DTO.Employee
{
    public class CashAccountDto
    {
        public string account { get; set; }
        public string bank { get; set; }
    }
}
