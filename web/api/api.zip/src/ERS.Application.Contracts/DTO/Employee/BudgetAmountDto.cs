namespace ERS.Application.Contracts.DTO.Employee
{
    public class BudgetAmountDto
    {
         public decimal Budget { get; set; }
        public bool  Stat { get; set; }//符合0
    }
}