namespace ERS.Application.Contracts.DTO.Employee
{
    public class Categoryname
    {
        public string categoryname { get; set; }
        public decimal budget { get; set; }
        public int categoryid { get; set; }
    }
}