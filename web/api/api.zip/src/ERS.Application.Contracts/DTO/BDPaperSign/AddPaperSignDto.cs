namespace ERS.DTO.BDPaperSign
{
    public class AddPaperSignDto
    {
        public string company { get; set; }
        public string company_code { get; set; }
        public string plant { get; set; }
        public string emplid { get; set; }
    }
}