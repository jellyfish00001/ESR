namespace ERS.DTO.BDTicketRail
{
    public class TicketRailDto
    {
        public string invcode { get; set; }
        public string invtype { get; set; }
        public string company { get; set; }
    }
}