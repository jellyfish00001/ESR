namespace ERS.DTO.BDTicketRail
{
    public class AddBDTicketRailDto
    {
        public string company { get; set; }
        public string ticketrail { get; set; }
        public string voucheryear { get; set; }
        public string vouchermonth { get; set; }
 
    }
}