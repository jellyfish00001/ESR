using System.Collections.Generic;

namespace ERS.DTO.BDTicketRail
{
    public class QueryBDTicketRailDto
    {
        public List<string> companylist { get; set; }
        public string ticketrail { get; set; }
        public string voucheryear { get; set; }
    }
}