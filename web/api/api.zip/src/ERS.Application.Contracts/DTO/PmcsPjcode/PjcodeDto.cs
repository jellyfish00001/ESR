namespace ERS.Application.Contracts.DTO.PJcode
{
    public class PjcodeDto
    {
        public string code { get; set; }
        public string description { get; set; }
    }
}