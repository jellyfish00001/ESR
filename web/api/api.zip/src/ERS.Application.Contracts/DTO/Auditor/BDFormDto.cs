namespace ERS.DTO.Auditor
{
    public class BDFormDto
    {
        public string formcode { get; set; }
        public string formname { get; set; }
    }
}