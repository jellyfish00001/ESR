using System;
namespace ERS.DTO.Account
{
    public class GenerateFormDto
    {
        public string carryno { get; set; }
        public DateTime? postdate { get; set; }
        public string acctantanme { get; set; }
        public string acctant { get; set; }
    }
}