namespace ERS.DTO.BDInvoiceRail
{
    public class AddBDInvoiceRailDto
    {
        public string qi { get; set; }
        public string invoicerail { get; set; }
        public decimal year { get; set; }
        public decimal month { get; set; }
        public decimal formatcode { get; set; }
        public string invoicetype { get; set; }
    }
}
