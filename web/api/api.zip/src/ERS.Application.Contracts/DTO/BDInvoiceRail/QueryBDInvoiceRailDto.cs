namespace ERS.DTO.BDInvoiceRail
{
    public class QueryBDInvoiceRailDto
    {
        public string invoicerail { get; set; }
        public decimal year { get; set; }
        public decimal month { get; set; }
        public string invoicetype { get; set; }
    }
}