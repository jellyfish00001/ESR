namespace ERS.DTO.MobileSign
{
    public class MobileOutput
    {
        public int rtnCode { get; set; }
        public string rtnMsg { get; set; }
    }
}