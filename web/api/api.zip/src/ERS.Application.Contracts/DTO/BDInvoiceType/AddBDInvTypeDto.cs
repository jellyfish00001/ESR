namespace ERS.DTO.BDInvoiceType
{
    public class AddBDInvTypeDto
    {
        public string invtypecode { get; set; }
        public string invtype { get; set; }
        public string company { get; set; }
        public string area { get; set; }
        public string category { get; set; }
    }
}