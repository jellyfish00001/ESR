namespace ERS.DTO.FinApprover
{
    public class AddFinApproverDto
    {
        public string company { get; set; }
        public string company_code { get; set; }
        public string plant { get; set; }
        public string rv1 { get; set; }
        public string rv2 { get; set; }
        public string rv3 { get; set; }
        public int category { get; set; }
    }
}