namespace ERS.Application.Contracts.DTO.Emporg
{
    public class EmporgDto
    {
        public string deptid{get;set;}
        public string descr{get;set;}
    }
}