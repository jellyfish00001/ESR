﻿namespace ERS.DTO.BDCompanyCategory
{
    public class BDCompanySiteParamDto
    {
        public string CompanyCategory { get; set; }
        public string Company { get; set; }
        public string Site { get; set; }
        public bool Primary { get; set; }
    }
}