﻿namespace ERS.DTO.BDVender
{

    public class BDVenderParamDto
    {
        public string Id { get; set; }
        public string VenderName { get; set; }

        public string VenderCode { get; set; }

        public string UnifyCode { get; set; }
    }
}