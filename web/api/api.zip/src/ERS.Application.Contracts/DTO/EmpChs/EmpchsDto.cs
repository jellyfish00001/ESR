namespace ERS.DTO.EmpChs
{
    public class EmpchsDto
    {
        public string emplid { get; set; }
        public string scname { get; set; }
    }
}