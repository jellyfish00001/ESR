namespace ERS.DTO.Application
{
    public class PayeeDto
    {
        public string payeedept { get; set; }
        public string bank { get; set; }
        public string payeename { get; set; }
        public string payeeid { get; set; }
    }
}