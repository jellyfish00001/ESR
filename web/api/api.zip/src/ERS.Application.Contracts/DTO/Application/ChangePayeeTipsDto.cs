namespace ERS.DTO.Application
{
    public class ChangePayeeTipsDto
    {
        public bool ischange { get; set; } = false;
        public string changeid { get; set; }
        public string changename { get; set; }
    }
}