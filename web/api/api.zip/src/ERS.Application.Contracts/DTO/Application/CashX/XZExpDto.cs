namespace ERS.DTO.Application.CashX
{
    public class XZExpDto
    {
        public string expcode { get; set; }
        public string description { get; set; }
    }
}