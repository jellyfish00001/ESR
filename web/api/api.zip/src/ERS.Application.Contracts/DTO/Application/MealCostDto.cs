﻿namespace ERS.DTO.Application
{
    public class MealCostDto
    {
        public int categoryid { get; set; }
        public string categoryname { get; set; }
        public decimal budget { get; set; }
        public string area { get; set; }
    }
}
