﻿namespace ERS.DTO.UberFare
{
    public interface IUberTransactionalDayService
    {

    }
}
