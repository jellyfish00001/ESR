﻿namespace ERS.DTO
{
    public class HelpManualDto
    {
        public string name { get; set; }
        public string path { get; set; }
        public string url { get; set; }
    }
}
