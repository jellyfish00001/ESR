namespace ERS.Application.Contracts.DTO.Eautono
{
    public class CreateUpdateEautonoDto
    {
        public string date { get; set; }
        public string no { get; set; }
        public string formcode { get; set; }
    }
}