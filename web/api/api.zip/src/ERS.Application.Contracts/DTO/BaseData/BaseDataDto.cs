using System.Collections.Generic;
namespace ERS.DTO.BaseData
{
    public class BaseDataDto
    {
        public List<string> company { get; set; }
        public List<string> rno { get; set; }
    }
}