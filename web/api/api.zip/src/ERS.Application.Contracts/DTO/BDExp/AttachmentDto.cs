namespace ERS.DTO.BDExp
{
    public class AttachmentDto
    {
        public string status { get; set; }
        public string msg { get; set; }
        public string data { get; set; }
        public int total { get; set; }
    }
}