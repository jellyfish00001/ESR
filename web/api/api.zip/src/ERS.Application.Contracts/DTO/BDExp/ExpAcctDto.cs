﻿namespace ERS.DTO
{
    public class ExpAcctDto
    {
        public string expcode { get; set; }
        public string expname { get; set; }
        public string acctcode { get; set; }
        public string acctname { get; set; }
    }
}
