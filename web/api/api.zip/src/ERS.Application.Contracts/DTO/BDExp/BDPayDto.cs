namespace ERS.DTO.BDExp
{
    public class BDPayDto
    {
        public string PayType { get; set; }
        public string PayName { get; set; }
    }
}