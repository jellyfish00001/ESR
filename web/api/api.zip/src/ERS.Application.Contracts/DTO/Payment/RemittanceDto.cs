namespace ERS.DTO.Payment
{
    public class RemittanceDto
    {
        public string bank { get; set; }
        public string company { get; set; }
        public string sysno { get; set; }
    }
}