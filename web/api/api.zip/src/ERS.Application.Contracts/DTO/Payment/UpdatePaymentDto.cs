namespace ERS.DTO.Payment
{
    public class UpdatePaymentDto
    {
        public string sysno { get; set; }
        public string bank { get; set; }
        public string rno { get; set; }
    }
}