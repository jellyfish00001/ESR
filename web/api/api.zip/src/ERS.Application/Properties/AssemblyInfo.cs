﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("ERS.Application.Tests")]
